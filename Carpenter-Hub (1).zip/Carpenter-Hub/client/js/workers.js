// Worker Management - Admin
let currentWorkerId = null;

function addWorker() {
    const name = document.getElementById('wName').value;
    const wage = parseFloat(document.getElementById('wWage').value);
    if(!name || !wage) return alert("વિગત ભરો");
    db.collection('workers').add({
        name, dailyWage: wage, createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }).then(() => {
        closeModal('addWorkerModal');
        loadWorkers();
    });
}

function loadWorkers() {
    const container = document.getElementById('workersList');
    db.collection('workers').orderBy('name').get().then(snapshot => {
        container.innerHTML = '';
        snapshot.forEach(doc => {
            const w = doc.data();
            const div = document.createElement('div');
            div.className = 'list-item';
            div.onclick = () => openWorkerDetail(doc.id, w);
            div.innerHTML = `<div><h4>${w.name}</h4><p>પગાર: ₹${w.dailyWage}/દિવસ</p></div><i class="fa-solid fa-chevron-right text-light"></i>`;
            container.appendChild(div);
        });
    });
}

async function openWorkerDetail(id, w) {
    currentWorkerId = id;
    document.getElementById('detailWorkerName').textContent = w.name;
    showModal('workerDetailModal');

    // Calculate Totals
    const attSnap = await db.collection('attendance').where('workerId', '==', id).get();
    const paySnap = await db.collection('payments').where('workerId', '==', id).get();

    let totalPayable = 0; attSnap.forEach(d => totalPayable += (d.data().payable || 0));
    let totalPaid = 0; paySnap.forEach(d => totalPaid += (d.data().amount || 0));

    document.getElementById('workerTotalPayable').textContent = `₹${totalPayable}`;
    document.getElementById('workerTotalPaid').textContent = `₹${totalPaid}`;
    document.getElementById('workerBalance').textContent = `₹${totalPayable - totalPaid}`;
}

async function addPayment() {
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    if(!amount) return alert("રકમ લખો");
    
    await db.collection('payments').add({
        workerId: currentWorkerId,
        amount: amount,
        date: new Date().toISOString().split('T')[0],
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    alert("ચુકવણી સેવ થઈ!");
    document.getElementById('paymentAmount').value = '';
    const wDoc = await db.collection('workers').doc(currentWorkerId).get();
    openWorkerDetail(currentWorkerId, wDoc.data());
}
